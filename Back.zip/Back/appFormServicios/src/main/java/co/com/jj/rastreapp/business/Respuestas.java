/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.jj.rastreapp.business;

/**
 *
 * @author jeio
 */
public class Respuestas {
    
    public static final int CREADO = 1;
    public static final int ACTUALIZADO = 2;
    public static final int ERROR = 0;
    public static final int SIN_DATOS = -1;
    public static final int EXISTE_REGISTRO = 3;
    
    
    
    
    
}
