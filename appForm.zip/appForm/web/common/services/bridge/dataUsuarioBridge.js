var app = angular.module('appForm.bridgeUser', []);

app.factory('BridgeUser', function(){
	return {
		usuario: {
		}
	}

});